
function prefill(min, rate){
  document.getElementById('init-amount').value = min;
  document.getElementById('init-rate').value = (rate*100).toFixed(2);
  window.scrollTo({top:document.getElementById('init-amount').offsetTop - 20, behavior:'smooth'});
}

document.addEventListener('DOMContentLoaded', function(){
  const btn = document.getElementById('calc-roi');
  if(!btn) return;
  btn.addEventListener('click', ()=>{
    const amount = parseFloat(document.getElementById('init-amount').value) || 0;
    const rate = (parseFloat(document.getElementById('init-rate').value) || 0)/100;
    const months = parseInt(document.getElementById('init-months').value) || 1;
    const out = document.getElementById('roi-output');
    if(amount<=0){ out.textContent = 'Enter a valid amount.'; return; }
    let total = amount; let rows = [];
    for(let i=1;i<=months;i++){
      const profit = total*rate;
      total = total + profit;
      rows.push({month:i, profit:profit, total:total});
    }
    out.textContent = 'Projected value after '+months+' month(s): $'+total.toFixed(2);
    const wrap = document.getElementById('roi-table-wrap');
    let html = '<table class="history-table"><thead><tr><th>Month</th><th>Profit</th><th>Total</th></tr></thead><tbody>';
    rows.forEach(r=> html += '<tr><td>'+r.month+'</td><td>$'+r.profit.toFixed(2)+'</td><td>$'+r.total.toFixed(2)+'</td></tr>');
    html += '</tbody></table>';
    wrap.innerHTML = html;
  });
});
