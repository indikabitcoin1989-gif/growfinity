
document.addEventListener('DOMContentLoaded', function(){
  // Dark mode (save to localStorage)
  const darkToggle = document.getElementById('dark-toggle');
  const current = localStorage.getItem('gf-theme') || (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  if(current === 'dark') document.documentElement.setAttribute('data-theme','dark');
  if(darkToggle) darkToggle.checked = (current === 'dark');
  if(darkToggle){
    darkToggle.addEventListener('change', ()=> {
      if(darkToggle.checked){ document.documentElement.setAttribute('data-theme','dark'); localStorage.setItem('gf-theme','dark'); }
      else { document.documentElement.removeAttribute('data-theme'); localStorage.setItem('gf-theme','light'); }
    });
  }

  // Mobile drawer
  const menuBtn = document.getElementById('menu-btn');
  const drawer = document.getElementById('mobile-drawer');
  const drawerClose = document.getElementById('drawer-close');
  if(menuBtn){ menuBtn.addEventListener('click', ()=> drawer.classList.add('open')); }
  if(drawerClose){ drawerClose.addEventListener('click', ()=> drawer.classList.remove('open')); }
  // close drawer when nav link clicked
  document.querySelectorAll('.drawer-nav a').forEach(a=> a.addEventListener('click', ()=> drawer.classList.remove('open')));

  // Quick ROI
  const qcalc = document.getElementById('quick-calc');
  if(qcalc) qcalc.addEventListener('click', ()=> {
    const plan = document.getElementById('quick-plan');
    const rate = parseFloat(plan.value);
    const amount = parseFloat(document.getElementById('quick-amount').value) || 0;
    const months = parseInt(document.getElementById('quick-months').value) || 1;
    const min = parseFloat(plan.selectedOptions[0].dataset.min) || 0;
    const out = document.getElementById('quick-result');
    if(amount < min){ out.textContent = 'Amount below plan minimum: $'+min; return; }
    let total = amount;
    for(let i=0;i<months;i++){ total = total*(1+rate); }
    out.textContent = 'Projected value after '+months+' month(s): $'+total.toFixed(2);
  });

  // Payment modal
  const payModal = document.getElementById('pay-modal');
  const openPay = document.getElementById('open-pay');
  const payClose = document.getElementById('pay-close');
  const payStart = document.getElementById('pay-start');
  const paySimFail = document.getElementById('pay-sim-fail');
  const payResult = document.getElementById('pay-result');
  if(openPay) openPay.addEventListener('click', ()=> { payModal.classList.remove('hidden'); payModal.setAttribute('aria-hidden','false'); });
  if(payClose) payClose.addEventListener('click', ()=> { payModal.classList.add('hidden'); payModal.setAttribute('aria-hidden','true'); payResult.textContent=''; });
  if(payStart) payStart.addEventListener('click', ()=> {
    const method = document.getElementById('pay-method').value;
    const amt = parseFloat(document.getElementById('pay-amount').value) || 0;
    payResult.textContent = 'Processing '+method+' payment of $'+amt.toFixed(2)+'... (simulated)';
    setTimeout(()=> payResult.textContent = 'Payment confirmed (simulated). Transaction ID: GF-'+Math.floor(Math.random()*900000+100000), 1200);
  });
  if(paySimFail) paySimFail.addEventListener('click', ()=> { payResult.textContent = 'Payment failed (simulated). Please try again.'; });

  // Live chat persistence
  const chatToggle = document.getElementById('live-toggle');
  const chatBox = document.getElementById('chat-box');
  const chatClose = document.getElementById('chat-close');
  const chatSend = document.getElementById('chat-send');
  const chatText = document.getElementById('chat-text');
  const chatMessages = document.getElementById('chat-messages');
  const chatDot = document.getElementById('chat-dot');

  // load messages from localStorage
  function loadChat(){ const d = JSON.parse(localStorage.getItem('gf-chat')||'[]'); chatMessages.innerHTML=''; d.forEach(m=> {
    const el = document.createElement('div'); el.className = 'msg '+m.role; el.textContent = m.text; chatMessages.appendChild(el);
  }); chatMessages.scrollTop = chatMessages.scrollHeight; }
  loadChat();

  function saveChat(){ const arr = Array.from(chatMessages.querySelectorAll('.msg')).map(m=> ({role: m.classList.contains('user') ? 'user' : 'bot', text: m.textContent})); localStorage.setItem('gf-chat', JSON.stringify(arr)); }
  if(chatToggle) chatToggle.addEventListener('click', ()=> { chatBox.classList.toggle('hidden'); chatDot.classList.add('hidden'); });
  if(chatClose) chatClose.addEventListener('click', ()=> chatBox.classList.add('hidden'));
  if(chatSend) chatSend.addEventListener('click', ()=> {
    const m = chatText.value.trim(); if(!m) return;
    const el = document.createElement('div'); el.className='msg user'; el.textContent=m; chatMessages.appendChild(el);
    chatText.value=''; saveChat();
    setTimeout(()=>{ const bot = document.createElement('div'); bot.className='msg bot'; bot.textContent='Thanks! Our team will reply soon.'; chatMessages.appendChild(bot); saveChat(); chatMessages.scrollTop = chatMessages.scrollHeight; chatDot.classList.add('hidden'); }, 700);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  });
  // show notification dot when new message arrives (simulated)
  setInterval(()=>{ if(Math.random()>0.85){ chatDot.classList.remove('hidden'); } }, 8000);

  // animate stats (count-up)
  document.querySelectorAll('.stat-num').forEach(el=> {
    const target = parseInt(el.dataset.target || el.textContent || '0', 10);
    let current = 0; const duration = 1100; const step = Math.ceil(target / (duration / 16));
    const t = setInterval(()=> { current += step; if(current >= target){ el.textContent = new Intl.NumberFormat().format(target); clearInterval(t); } else el.textContent = new Intl.NumberFormat().format(current); }, 16);
  });

});
